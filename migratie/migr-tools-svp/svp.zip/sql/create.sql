##########################################################
# This script contains the DML statements to (re)create the
# tables and sequences, necessary for the Spontaan
# VergelijkingsProgramma (SVP) to perform it's tasks.
#
# Note: PostgreSQL 8.2 or newer is required for this script,
#       due to the "DROP ... IF EXISTS" construction.
##########################################################


##########################################################
# Clean up all the items created lateron with this script.
##########################################################
DROP TABLE IF EXISTS svp_bericht;
DROP SEQUENCE IF EXISTS svp_bericht_id_sequence;


##########################################################
# Create the sequence for svp_bericht.svp_bericht_id.
##########################################################
CREATE SEQUENCE svp_bericht_id_sequence;


##########################################################
# Create the table for containing LO3 messages.
##########################################################
CREATE TABLE svp_bericht (
  svp_bericht_id integer not null unique default nextval('svp_bericht_id_sequence'),
  bericht_data text,
  bericht_collection integer,
  bericht_soort char(5),
  a_nr bigint,
  PRIMARY KEY (svp_bericht_id)
);


##########################################################
# Create an index for accessing svp_bericht by a_nr.
##########################################################
CREATE INDEX svp_bericht_idx_0 on svp_bericht (a_nr);

